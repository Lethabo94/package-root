#Function 1
'''Return sum of all items in array'''

#Function 2
'''Return nth term in fibonacci sequence'''

#Function 3
'''Return n!'''

#Function 4
'''Return word in reverse'''

#Function 5
'''Return array of items, sorted in ascending order'''

#Function 6
'''Return array of items, sorted in ascending order'''

#Function 7
'''Return array of items, sorted in ascending order'''
